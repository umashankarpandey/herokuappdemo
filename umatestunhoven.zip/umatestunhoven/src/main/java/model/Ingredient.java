package model;

public class Ingredient {

}
